<?php
namespace stats;
use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\utils\Config;
use pocketmine\lang\BaseLang;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use jojoe77777\FormAPI\CustomForm;
use pocketmine\math\Vector3;
use pocketmine\level\particle\FloatingTextParticle;
use pocketmine\utils\TextFormat as C;
class stats extends PluginBase implements Listener
{
    /** @var PurePerms */
    private $purePerms;
    private $pureChat;
    private $con;

    public function onEnable()
    {
        $this->getServer()->getPluginManager()->registerEvents($this, $this);

        $this->purePerms = $this->getServer()->getPluginManager()->getPlugin("PurePerms");
        $this->pureChat = $this->getServer()->getPluginManager()->getPlugin("PureChat");
        $this->saveDefaultConfig();
        $this->reloadConfig();
        if (!file_exists($this->getDataFolder() . "config.yml")) {
            @mkdir($this->getDataFolder());
            file_put_contents($this->getDataFolder() . "config.yml", $this->getResource("config.yml"));
        }
        $hostname = $this->getConfig()->get("hostname");
        $username = $this->getConfig()->get("user");
        $password = $this->getConfig()->get("password");
        $db = $this->getConfig()->get("db");
        $this->con = new \mysqli($hostname, $username, $password, $db);
        if ($this->con->connect_error) {
            die("Connection failed: " . $this->con->connect_error);
        }
        $this->getLogger()->notice("Connected to database!");
        $sql = "CREATE TABLE IF NOT EXISTS players (pname VARCHAR(255), tag VARCHAR(255), kills INT, deaths INT, kdr VARCHAR(255))";
        if ($this->con->query($sql)) {
            $this->getLogger()->notice("Players table created!");
        }
    }

    public function getPlayerDisplayRank(Player $player): string
    {
        $display = $this->pureChat->getNametag($player);
        if ($display !== null) {
            return $display;
        } else {
            return " ";
        }
    }

    /**
     * @param Player $player
     * @param null $levelName
     * @return string
     */
    public function onJoin(PlayerJoinEvent $event)
    {
        $player = $event->getPlayer();
        $name = $player->getDisplayName();
        $rank = $this->getPlayerDisplayRank($player);
        $frank = str_replace("•", "#", str_replace("§", "&", $rank));
        $sql = "SELECT * FROM players WHERE pname='$name'";
        $results = $this->con->query($sql);
        if (!$results->num_rows > 10) {
            $sql = "INSERT INTO players (pname, tag, kills, deaths, kdr) VALUES ('$name', '$frank', 0, 0, '0')";
            if ($this->con->query($sql)) {
                $this->getLogger()->notice("Player $name has been added to the database.");
            }
        } else {
            while ($row = $results->fetch_assoc()) {


                $sqlll = "UPDATE players SET tag='$frank' WHERE pname='$name'";
            $this->con->query($sqlll);
            }
        }



        $body = "§l§cTop Kills" . "§r\n§8↝ §l§7Leaderboard§r§8 ↜§r" . "\n\n";
        $sql = "SELECT tag, pname, kills, deaths, kdr FROM players ORDER BY kills DESC";
        $result = $this->con->query($sql);
        if ($result->num_rows > 0) {
            $i = 0;
            while($row = $result->fetch_assoc()){
                if($i < 10){
                    $i++;
                    switch ($i) {
                        case 1:
                            $place = C::GREEN . "";
                            $y = $i / 4.125;
                            break;
                        case 2:
                            $place = C::GREEN . "";
                            $y = $i / 4.125;
                            break;
                        case 3:
                            $place = C::GREEN . "";
                            $y = $i / 4.125;
                            break;
                        case 4:
                            $place = C::GREEN . "";
                            $y = $i / 4.125;
                            break;    
                        case 5:
                            $place = C::GREEN . "";
                            $y = $i / 4.125;
                            break;
                        case 6:
                            $place = C::GREEN . "";
                            $y = $i / 4.125;
                            break;       
                        case 7:
                            $place = C::GREEN . "";
                            $y = $i / 4.125;
                            break;  
                        case 8:
                            $place = C::GREEN . "";
                            $y = $i / 4.125;
                            break;       
                        case 9:
                            $place = C::GREEN . "";
                            $y = $i / 4.125;
                            break;       
                        case 10:
                            $place = C::GREEN . "";
                            $y = $i / 4.125;
                            break;  
                    }
                    $body .= $place . " " . C::AQUA . str_replace("&", "§", $row["tag"]) . C::GRAY . " ↝ " . C::RED. $row["kills"] . "\n";
                     // $this->getServer()->getDefaultLevel()->addParticle(new FloatingTextParticle(new Vector3($this->getConfig()->get("x") + 0.5, $this->getConfig()->get("y") + 0.5 - $y, $this->getConfig()->get("z") + 0.5), $place . " " . C::AQUA . str_replace("&", "§", $row["tag"]) . C::GRAY . " - " . C::WHITE . $row["kills"]), [$player]);
                }
            }
        } else {

        }
        $this->getServer()->getDefaultLevel()->addParticle(new FloatingTextParticle(new Vector3($this->getConfig()->get("x") + 0.5, $this->getConfig()->get("y") + 0.75, $this->getConfig()->get("z") + 0.5), $body), [$player]);
    }

    public function onCommand(CommandSender $sender, Command $cmd, String $label, array $args): bool
    {
        $player = $sender->getName();
        if ($cmd->getName() == "stats") {
            $Api = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
            if ($Api) {
                $form = new CustomForm(function (Player $player, $data = null) {

                });
                $sql = "SELECT pname, deaths, kills, tag, kdr FROM players WHERE pname = '$player'";
                $results = $this->con->query($sql);
                if (!$results->num_rows > 0) {
                    $form->addLabel("Error");
                } else {
                    while ($row = $results->fetch_assoc()) {
                        $rank = $row["tag"];
                        $frank = str_replace("&", "§", $rank);
                        $deaths = $row["deaths"];
                        $kills = $row["kills"];
                        $kdr = "";
                        if($deaths == 0 or $kills == 0){
                            $kdr = 0;
                        } else {
                            $kdr = $kills/$deaths;
                        }

                        $form->addLabel("Tag = $frank");
                        $form->addLabel("Deaths = $deaths");
                        $form->addLabel("Kills = $kills");
                        $form->addLabel("KDR = $kdr");
                    }
                }
                $sender->sendForm($form);
            } else {
                $sender->sendMessage("Please install FormAPI;");
            }
            return true;
        } else if($cmd->getName() == "statstext"){
            if($sender instanceof Player){
                $this->getConfig()->set("x", $sender->getFloorX());
                $this->getConfig()->set("y", $sender->getFloorY());
                $this->getConfig()->set("z", $sender->getFloorZ());
                $this->getConfig()->save();
                $sender->sendMessage(C::GREEN."LeaderBoards spawn coordinates set in your location, please re-login...");
            } else {
                $sender->sendMessage(C::YELLOW."Please use this command in-game!");
            }
            return true;
        }
        return true;
    }

    public function onDeath(PlayerDeathEvent $event)
    {
        $player = $event->getPlayer();
        $name = $player->getName();
        $sql = "SELECT pname, tag, deaths, kills FROM players WHERE pname='$name'";
        $results = $this->con->query($sql);
        if (!$results->num_rows > 0) {

            $this->getLogger()->error("Player $name is not on our database!");

        } else {
            while ($row = $results->fetch_assoc()) {
                $deaths = $row["deaths"] + 1;
             
                $kills = $row["kills"];
                if($deaths == 0 or $kills == 0){
                    $kdr = 0;
                } else {
                    $kdr = $kills/$deaths;
                }

                $sql = "UPDATE players SET deaths=$deaths, kdr='$kdr' WHERE pname='$name'";
                $this->con->query($sql);
            }
        }
        $entity = $event->getEntity();
        $cause = $entity->getLastDamageCause(); //get the last damage cause
        if ($cause instanceof \pocketmine\event\entity\EntityDamageByEntityEvent) { //if the cause is by an another entity
            $killer = $cause->getDamager(); //gets the event damager
            if ($killer instanceof Player) {
                $kname = $killer->getName();
                $sql = "SELECT pname, tag, deaths, kills FROM players WHERE pname='$kname'";
                $results = $this->con->query($sql);
                if (!$results->num_rows > 0) {

                    $this->getLogger()->error("Player $killer is not on our database!");

                } else {
                    while ($row = $results->fetch_assoc()) {
                        $kills = $row["kills"] + 1;
                        $deaths = $row["deaths"];
                        $dsss = "";
                        if($deaths == 0 or $kills == 0){
                            $kdr = 0;
                        } else {
                            $kdr = $kills/$deaths;
                        }
                        $sql = "UPDATE players SET kills=$kills, kdr='$kdr' WHERE pname='$kname'";
                        $this->con->query($sql);
                    }
                }
            }
        }

    }

}